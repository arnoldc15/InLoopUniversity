﻿using Microsoft.EntityFrameworkCore;

namespace Student.Application.Interfaces;

public interface IQueryDbContext
{
    DbSet<Domain.Entities.Student> Student { get; set; }
}
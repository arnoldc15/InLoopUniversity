﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;

namespace Student.Application.Queries.GetStudent
{
    public class StudentProfile : Profile
    {
        public StudentProfile()
        {
            CreateMap<Domain.Entities.Student, StudentViewModel>()
                .ForMember(dest => dest.Enrolments, opts => opts.MapFrom(src => src.Enrolments));
            CreateMap<Domain.Entities.Enrolment, EnrolmentViewModel>();
        }
    }
}

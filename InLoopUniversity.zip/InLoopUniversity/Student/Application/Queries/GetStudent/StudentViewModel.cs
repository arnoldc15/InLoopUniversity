﻿namespace Student.Application.Queries.GetStudent;

public class StudentViewModel
{
    public int StudentId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public bool IsCompleted { get; set; }

    public List<EnrolmentViewModel> Enrolments { get; set; }
}

public class EnrolmentViewModel
{
    public int EnrolmentId { get; set; }

    public string CourseName { get; set; }
}
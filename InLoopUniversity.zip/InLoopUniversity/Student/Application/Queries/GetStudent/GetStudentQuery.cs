﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Student.Application.Interfaces;

namespace Student.Application.Queries.GetStudent;

public class GetStudentQuery : IRequest<List<StudentViewModel>>
{
    public class GetStudentQueryHandler : IRequestHandler<GetStudentQuery, List<StudentViewModel>>
    {
        private readonly IQueryDbContext _context;
        private readonly IMapper _mapper;

        public GetStudentQueryHandler(IQueryDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<StudentViewModel>> Handle(GetStudentQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<List<StudentViewModel>>(await _context.Student
                .Include(s => s.Enrolments)
                .ToListAsync(cancellationToken));
        }
    }
}
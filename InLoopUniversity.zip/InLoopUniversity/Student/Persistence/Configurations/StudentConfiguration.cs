﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Student.Persistence.Configurations;

public class StudentConfiguration : IEntityTypeConfiguration<Domain.Entities.Student>
{
    public void Configure(EntityTypeBuilder<Domain.Entities.Student> builder)
    {
        builder.ToTable("student");
        builder.HasKey("StudentId");

        builder.HasMany(b => b.Enrolments)
            .WithOne(s => s.Student);
    }
}
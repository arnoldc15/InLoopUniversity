using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Student.Application.Queries.GetStudent;

namespace Student.WebApi.Controllers;

[ApiController]
[Route("[controller]")]
public class StudentController : ControllerBase
{
    private readonly IMapper _mapper;
    private readonly IMediator _mediator;

    public StudentController(IMapper mapper, IMediator mediator)
    {
        _mapper = mapper;
        _mediator = mediator;
    }

    [HttpGet]
    public async Task<List<StudentViewModel>> GetStudents(CancellationToken cancellationToken)
    {
        return await _mediator.Send(new GetStudentQuery(), cancellationToken);
    }
}
﻿namespace Student.Domain.Entities;

public class Enrolment
{
    public int EnrolmentId { get; set; }
    public int StudentId { get; set; }
    public Student Student { get; set; }
    public string CourseName { get; set; }
    public bool IsCompleted { get; set; }
}
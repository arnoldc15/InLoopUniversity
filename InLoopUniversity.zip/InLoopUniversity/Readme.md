


Requirements Fully Completed:
1.	Reading enrolments as a collection sub-resource of a student resource, returning the list of enrolments (both completed & uncompleted)
-	This can be verified by running Student.WebApi project
2.	If the enrolment would cause the student to have > 5 incomplete subjects, the enrolment should be rejected
-	This can be verified by running Enrolment.WebApi project
3.	Submit a sketch of a system architecture for a complex web application
-	The diagram can be found under the solution items folder / root directory. Though It wasn�t in the requirement, I opted to use the sample Enrolment application to design a high-level distributed web architecture that can be enterprise ready.
-   These enables me to explain my thought process for the other requirements that I have not completed within the time period.

Partially/Not Completed Requirements:
1.	Creating/Reading Students and Subjects 
�   These were less prioritized since it is low complexity and will not be able to showcase my skillset fully.
2.	If the enrolment is successful, a notification should be sent to the student. For the purposes of the exercise, the notification can be simulated by dumping a file to disk. 
�	To do this properly, a background job or an async event would need to be called to push notifications and can be re-run for failure.  

Enrolment Solution Explanation:
1.	I am usually pragmatic and won�t design simple applications to be distributed. However, it felt having it in a form of distributed applications will showcase more of my skillset on design and architecture.
2.	I used onion architecture and CQRS pattern in creating the APIs and Microservices. These uses IOC a lot and decouples each layer with a very clear data flow. I have used this pattern in my previous job applications 3 years ago and it saved me time in this exercise with a pre-written boilerplate codes and scaffolding.
3.	I tried to demonstrate my unit testing / TDD approach even for the simplest logic. These shows how decouple each layer of my code and how easy it is to test and extend.
4.	I have used seeded in-memory DB rather than an actual DB to save time and ease of deployment/running it from the reviewer machine. However, the application is ready to hook up to variety of DB by just hooking up a proper connection string.
5.	I put in empty solution folders for the microservices I have not finished just to showcase how I would design bounded context on each domain.
6.	Each individual microservices has its own database. By injecting messaging bus for eventual consistency, each DB will have its own table it owns and snapshot of data from other microservices (tables with suffix snapshots).
7.	Auth/Logging/Validations and other basic concepts have been purposely not done due to time constraints.

﻿using Enrolment.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Enrolment.Persistence.Configurations;

public class EnrolmentConfiguration : IEntityTypeConfiguration<Domain.Entities.Enrolment>
{
    public void Configure(EntityTypeBuilder<Domain.Entities.Enrolment> builder)
    {
        builder.ToTable("enrolment");
        builder.HasKey("EnrolmentId");


        builder.HasMany(b => b.EnroledSubjects)
            .WithOne(s => s.Enrolment);
    }
}
﻿using Enrolment.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Enrolment.Persistence.Configurations;

public class EnroledSubjectConfiguration : IEntityTypeConfiguration<EnroledSubject>
{
    public void Configure(EntityTypeBuilder<EnroledSubject> builder)
    {
        builder.ToTable("enroledsubject");
        builder.HasKey("EnroledSubjectId");


    }
}
﻿using Enrolment.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Enrolment.Persistence.Configurations.CdcTables;

public class SubjectConfiguration: IEntityTypeConfiguration<Subject>
{
    public void Configure(EntityTypeBuilder<Subject> builder)
    {
        builder.ToTable("subjectsnapshot");
        builder.HasKey("SubjectId");
    }
}

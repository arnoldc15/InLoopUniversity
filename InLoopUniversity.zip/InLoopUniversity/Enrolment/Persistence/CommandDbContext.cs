﻿using Enrolment.Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Enrolment.Persistence;

public class CommandDbContext : QueryDbContext, ICommandDbContext
{
    public CommandDbContext(DbContextOptions options)
        : base(options)
    {
    }
    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return base.SaveChangesAsync(cancellationToken);
    }
}
﻿using Enrolment.Application.Interfaces;
using Enrolment.Persistence.Configurations;
using Microsoft.EntityFrameworkCore;

namespace Enrolment.Persistence;

public class QueryDbContext : DbContext, IQueryDbContext
{
    public QueryDbContext(DbContextOptions options) : base(options)
    {
    }

    public DbSet<Domain.Entities.Enrolment> Enrolments { get; set; }
    public DbSet<Domain.Entities.EnroledSubject> EnroledSubjects { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(EnrolmentConfiguration).Assembly);
    }
}
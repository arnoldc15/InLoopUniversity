﻿using AutoMapper;
using Command = Enrolment.Application.Commands.CreateEnrolment;

namespace Enrolment.WebApi.Requests.CreateEnrolment;

public class CreateEnrolmentProfile : Profile
{
    public CreateEnrolmentProfile()
    {
        CreateMap<CreateEnrolmentRequest, Command.CreateEnrolmentCommand>();
    }
}
﻿namespace Enrolment.WebApi.Requests.CreateEnrolment;

public class CreateEnrolmentRequest
{
    public int StudentId { get; set; }
    public int CourseId { get; set; }
    public List<int> SubjectIds { get; set; }
}
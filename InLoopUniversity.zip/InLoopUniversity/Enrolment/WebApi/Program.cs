using Enrolment.Application.Commands.CreateEnrolment;
using Enrolment.Application.Interfaces;
using Enrolment.Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAutoMapper(typeof(Program));
builder.Services.AddMediatR(typeof(Program), typeof(CreateEnrolmentCommand));

builder.Services.AddDbContext<IQueryDbContext, QueryDbContext>(options =>
    options.UseInMemoryDatabase("InMemoryDB"));
builder.Services.AddDbContext<ICommandDbContext, CommandDbContext>(options =>
    options.UseInMemoryDatabase("InMemoryDB"));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
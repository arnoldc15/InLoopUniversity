using Enrolment.Application.Commands.CreateEnrolment;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Enrolment.WebApi.Requests.CreateEnrolment;

namespace Enrolment.WebApi.Controllers;

[ApiController]
[Route("[controller]")]
public class EnrolmentController : ControllerBase
{
    private readonly IMapper _mapper;
    private readonly IMediator _mediator;

    public EnrolmentController(IMapper mapper, IMediator mediator)
    {
        _mapper = mapper;
        _mediator = mediator;
    }

    [HttpPost]
    public async Task CreateEnrolment(CreateEnrolmentRequest request, CancellationToken cancellationToken)
    {
        var command = _mapper.Map<CreateEnrolmentCommand>(request);
        await _mediator.Send(command, cancellationToken);
    }
}
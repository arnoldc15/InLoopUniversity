﻿using System.ComponentModel.DataAnnotations;
using Enrolment.Application.Interfaces;
using Enrolment.Domain.Entities;
using MediatR;

namespace Enrolment.Application.Commands.CreateEnrolment;

public class CreateEnrolmentCommand : IRequest
{
    public int StudentId { get; set; }
    public int CourseId { get; set; }
    public List<int> SubjectIds { get; set; }

    public class CreateEnrolmentCommandHandler : IRequestHandler<CreateEnrolmentCommand>
    {
        private readonly ICommandDbContext _context;

        public CreateEnrolmentCommandHandler(ICommandDbContext context)
        {
            _context = context;
        }

        public async Task<Unit> Handle(CreateEnrolmentCommand request, CancellationToken cancellationToken)
        {
            if (request.SubjectIds.Count > 5)
                throw new ValidationException("The maximum subjects per course is 5.");

            await _context.Enrolments.AddAsync(new Domain.Entities.Enrolment
            {
                StudentId = request.StudentId,
                CourseId = request.CourseId,
                EnroledSubjects = request.SubjectIds.Select(id => new EnroledSubject() { SubjectId = id }).ToList()
            }, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);

            return Unit.Value;
        }
    }
}


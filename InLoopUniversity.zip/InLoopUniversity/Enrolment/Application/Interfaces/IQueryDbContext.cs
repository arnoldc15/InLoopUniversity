﻿using Enrolment.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Enrolment.Application.Interfaces;

public interface IQueryDbContext
{
    DbSet<Domain.Entities.Enrolment> Enrolments { get; set; }
}
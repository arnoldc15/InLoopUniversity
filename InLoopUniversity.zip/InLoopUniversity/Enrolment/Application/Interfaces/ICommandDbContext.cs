﻿namespace Enrolment.Application.Interfaces;

public interface ICommandDbContext : IQueryDbContext
{
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
﻿namespace Enrolment.Domain.Entities;

public class Subject
{
    public int SubjectId { get; set; }
    public int Name { get; set; }
}
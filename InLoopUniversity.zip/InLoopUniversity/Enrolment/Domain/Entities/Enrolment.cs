﻿namespace Enrolment.Domain.Entities;

public class Enrolment
{
    public int EnrolmentId { get; set; }
    public int StudentId { get; set; }
    public int CourseId { get; set; }
    public ICollection<EnroledSubject> EnroledSubjects { get; set; } =
        new HashSet<EnroledSubject>();
}
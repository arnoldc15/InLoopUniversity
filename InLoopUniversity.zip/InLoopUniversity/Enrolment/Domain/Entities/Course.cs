﻿namespace Enrolment.Domain.Entities;

public class Course
{
    public int CourseId { get; set; }
    public int Name { get; set; }
}
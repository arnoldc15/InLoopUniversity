﻿namespace Enrolment.Domain.Entities;

public class EnroledSubject
{
    public int EnroledSubjectId { get; set; }
    public int EnrolmentId { get; set; }
    public int SubjectId { get; set; }
    public Enrolment Enrolment { get; set; }
}
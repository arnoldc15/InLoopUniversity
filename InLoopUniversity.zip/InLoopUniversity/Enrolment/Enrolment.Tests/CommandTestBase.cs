﻿using System;
using System.Collections.Generic;
using AutoFixture;
using AutoFixture.AutoMoq;

namespace Enrolment.Tests;

public class CommandTestBase : IDisposable
{
    private readonly Guid _dbGuid = Guid.NewGuid();

    private readonly List<IDisposable> _disposables = new();

    protected readonly IFixture Fixture;

    public CommandTestBase()
    {
        Fixture = new Fixture()
            .Customize(new AutoMoqCustomization());
    }

    public void Dispose()
    {
        foreach (var disposable in _disposables) disposable.Dispose();
        GC.SuppressFinalize(this);
    }

    protected InMemoryCommandDbContext GetContext()
    {
        var result = DbContextFactory.CreateInMemoryCommandContext(_dbGuid);
        _disposables.Add(result);
        return result;
    }
}
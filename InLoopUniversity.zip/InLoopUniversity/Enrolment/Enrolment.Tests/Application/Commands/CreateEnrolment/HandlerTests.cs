﻿using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading;
using AutoFixture;
using Enrolment.Application.Commands.CreateEnrolment;
using Shouldly;
using Xunit;

namespace Enrolment.Tests.Application.Commands.CreateEnrolment;

public class HandlerTests : CommandTestBase
{
    public HandlerTests()
    {
        Db = GetContext();
    }

    private InMemoryCommandDbContext Db { get; }

    [Fact]
    public async void WhenEnrolmentIsValidAndHasCorrectNumberOfSubjects_ShouldSaveEnrolmentCorrectly()
    {
        var subjects = Fixture.CreateMany<int>(5).ToList();
        var command = Fixture.Build<CreateEnrolmentCommand>()
            .With(c => c.SubjectIds, subjects)
            .Create();

        var handler =
            new CreateEnrolmentCommand.CreateEnrolmentCommandHandler(Db);

        var result = await handler.Handle(command, CancellationToken.None);
        var db = Db.Enrolments;

        db.Count().ShouldBe(1);
        db.Single().StudentId.ShouldBe(command.StudentId);
        db.Single().CourseId.ShouldBe(command.CourseId);
    }

    [Fact]
    public async void WhenEnrolmentIsValidAndHasCorrectNumberOfSubjects_ShouldSaveEnroledSubjectsCorrectly()
    {
        var subjects = Fixture.CreateMany<int>(5).ToList();
        var command = Fixture.Build<CreateEnrolmentCommand>()
            .With(c => c.SubjectIds, subjects)
            .Create();

        var handler =
            new CreateEnrolmentCommand.CreateEnrolmentCommandHandler(Db);

        var result = await handler.Handle(command, CancellationToken.None);
        var db = Db.EnroledSubjects;

        db.Count().ShouldBe(subjects.Count);
        db.Any(d=>d.SubjectId == subjects.First()).ShouldBeTrue();
    }

    [Fact]
    public async void WhenEnrolmentExceededAllowedNumberOfSubjects_ShouldThrowValidationException()
    {
        var subjects = Fixture.CreateMany<int>(6).ToList();
        var command = Fixture.Build<CreateEnrolmentCommand>()
            .With(c => c.SubjectIds, subjects)
            .Create();

        var handler =
            new CreateEnrolmentCommand.CreateEnrolmentCommandHandler(Db);

        var result = await handler.Handle(command, CancellationToken.None).ShouldThrowAsync<ValidationException>();
    }
}
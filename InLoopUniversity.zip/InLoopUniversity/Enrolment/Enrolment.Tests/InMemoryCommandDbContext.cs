﻿using Enrolment.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Enrolment.Tests;

public class InMemoryCommandDbContext : CommandDbContext
{
    public InMemoryCommandDbContext(DbContextOptions options) : base(options)
    {
        
    }
}
﻿using System;
using Microsoft.EntityFrameworkCore;

namespace Enrolment.Tests;

public class DbContextFactory
{
    public static InMemoryCommandDbContext CreateInMemoryCommandContext(Guid uniqueGuid)
    {
        var options = new DbContextOptionsBuilder<InMemoryCommandDbContext>()
            .UseInMemoryDatabase(uniqueGuid.ToString())
            .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
            .EnableSensitiveDataLogging()
            .Options;

        var context = new InMemoryCommandDbContext(options);
        context.Database.EnsureCreated();

        context.SaveChanges();

        return context;
    }


    public static void Destroy(DbContext context)
    {
        context.Database.EnsureDeleted();
        context.Dispose();
    }
}